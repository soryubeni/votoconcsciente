# Como adicionar a foto de um candidato

1. Coloque o arquivo de imagem (`.jpg`, `.jpeg`, `.png` ou `.webp`) dentro
   desta pasta (`public/candidatos/`). Dica: use um nome parecido com o
   `slug` do candidato para facilitar, por exemplo `lula.jpg`.

2. Abra o arquivo `src/data/candidatos.ts`.

3. Encontre o candidato desejado (pelo nome) e adicione (ou edite) a linha
   `foto`, apontando para o arquivo que você colocou aqui. Por exemplo:

   ```ts
   {
     id: "c01",
     slug: "luis-inacio-lula-da-silva",
     nome: "Luis Inácio Lula da Silva",
     ...
     foto: "/candidatos/lula.jpg",
     ...
   }
   ```

   Repare que o caminho sempre começa com `/candidatos/` (sem incluir
   `public`) e deve ter o mesmo nome do arquivo que você colocou na pasta.

4. Salve o arquivo. Pronto — a foto vai aparecer automaticamente no card
   da lista de candidatos e na página do candidato.

Se um candidato ainda não tiver a linha `foto` (ou se ela ficar apontando
para um arquivo que não existe), o site mostra um ícone padrão no lugar,
então não tem problema deixar para depois.
