import { Linkedin } from "lucide-react";

// Ícones das redes sociais usados na página do candidato.
// O lucide-react não tem um ícone oficial do "X" (antigo Twitter) nem do
// Instagram nas versões mais recentes, então esses dois foram desenhados
// como SVG aqui mesmo. Não precisa mexer neste arquivo para adicionar
// redes sociais a um candidato — isso é feito em src/data/candidatos.ts.

function IconeX({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function IconeInstagram({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
    >
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

export type NomeRedeSocial = "X" | "Instagram" | "LinkedIn";

export function IconeRedeSocial({
  rede,
  className,
}: {
  rede: NomeRedeSocial | string;
  className?: string;
}) {
  switch (rede) {
    case "X":
      return <IconeX className={className} />;
    case "Instagram":
      return <IconeInstagram className={className} />;
    case "LinkedIn":
      return <Linkedin aria-hidden="true" className={className} />;
    default:
      return null;
  }
}
